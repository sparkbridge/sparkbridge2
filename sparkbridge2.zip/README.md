# SparkBridge2

> ✨向BDS推出的使用Onebot标准的机器人框架✨

 - Nodejs提供强力支持
 - Onebot框架，兼容广泛
 - 同时支持String,array工作方式
 - NilBridge原班人马为您带来全新的互通机器人方案。
 - 支持内核分离方案，轻松二次开发。


[开始查阅](https://sparkbridge.cn)

[Minebbs链接](https://www.minebbs.com/resources/sparkbridge-bot-qq.5480/)