# SparkBridge2

## 本地调试模式

文件存储位于`testdata/`文件夹，代替`plugins/sparkbridge2/`

请严格按照`spark.getFileHelper`来使用，不要私自读取文件