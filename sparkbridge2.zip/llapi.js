// LiteLoader-AIDS automatic generated
/// <reference path="/home/lition/文档/litaloader-api/dts/helperlib/src/index.d.ts"/> 



// 单独开发请在这里引入你们的 API 地址
