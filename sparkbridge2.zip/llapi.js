// LiteLoader-AIDS automatic generated
/// <reference path="c:\Users\dream\Documents\llaids/dts/helperlib/src/index.d.ts"/> 


// 单独开发请在这里引入你们的 API 地址
