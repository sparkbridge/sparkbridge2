# SparkBridge2

由第二代框架升级底层构架而来，耗时两个月进行重构

基于onebot协议开发而来，支持mirai/go-cqhttp等bot核心

提供内核分离方案，可以进行二次开发脱离BDS进行运行。