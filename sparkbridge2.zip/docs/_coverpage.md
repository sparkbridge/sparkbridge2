<!-- _coverpage.md -->

# <div class="font-title">SparkBridge</div>

<div align="center">
    <img width="160" high='160' src="https://s1.ax1x.com/2023/01/28/pSUj4DH.png" alt="logo">
</div>


> ✨使用Onebot协议的BDS机器人✨

 - NilBridge原班人马为您带来全新的互通机器人方案。
 - 支持内核分离方案，轻松二次开发。


[开始查阅](/README.md)
