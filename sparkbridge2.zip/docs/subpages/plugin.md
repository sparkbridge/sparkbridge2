# 装载插件

通常下载下来的插件是zip文件，解压到文件夹后把文件夹放入到`plugins/sparkbridge2/plugins`文件夹。

sb1的插件sb2无法支持，请等待更新。

![](./plugin/dir.png)

