# 插件中心

>要是你也愿意为我们提供插件，欢迎来[仓库](https://github.com/sparkbridge/sparkbridge2/tree/main/docs)提交Pull Request哦

## os

群内自助查询服务器状态

![](/store/sparkos.jpg)

链接：https://www.minebbs.com/resources/spark-os.5657/


## niuzi 牛子系统

在你的群里面和群友一起比比谁的牛子长（）

![](/store/niuzi.png)

链接：敬请期待

## setu 涩图插件

在你的群里面获取一张涩图

![](/store/setu.png)

链接：敬请期待

## DeathMessages - 更生动具体的死亡信息

来自[@Tsubasa6848](https://www.minebbs.com/members/tsubasa6848.39046/)的扩展，内置sparkAPI，丰富的死亡讯息（移植了java）以及自动转发群

![](/store/diemsg1.jpg)

链接：https://www.minebbs.com/resources/deathmessages-java.4897/

## Advancements - 还原Java版全部进度/成就系统

来自[@Tsubasa6848](https://www.minebbs.com/members/tsubasa6848.39046/)的扩展，移植java几乎所有成就，内置sparkAPI，完成时自动转发群聊。

![](/store/adventure.jpg)

链接：https://www.minebbs.com/resources/advancements-java.4949/



## spark.qbot

基于青云客AI的聊天BOT

![](/store/qbot.jpg)

链接:https://www.minebbs.com/resources/spark-qbot.5744/

## spark.pic

群内获取二次元图片

![](/store/spark.pic.png)

链接：https://www.minebbs.com/resources/spark-pic.5743/

>>[前往minebbs以寻找更多](https://www.minebbs.com/search/1291389/?q=spark.&o=relevance)

## [-->装载插件](/subpages/plugin.md)