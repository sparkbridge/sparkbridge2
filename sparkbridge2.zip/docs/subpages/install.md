# 安装SparkBridge
我们有两种安装方式，在其中二选一即可：
## 从Minebbs下载

从我们的官方页面：https://www.minebbs.com/resources/sparkbridge.5480/

点击购买下载即可。

下载下来的压缩包请解压。

然后把`.llplugin`文件放到BDS的plugins文件夹

## 从Github安装

> [!WARNING] 请连不上的同学自备科学上网软件

> [!WARNING] 此处为开发中Sparkbridge施工现场，直接从此处git clone有可能得到功能测试中的半成品，如果你知道你在做什么请随意。

### Git Clone

来到BDS的`plugins/nodejs`文件夹

执行

``` bash
git clone https://github.com/sparkbridge/sparkbridge2.git
```

clone结束后，开启BDS

`什么？命令不存在？这边建议你去minebbs下载捏`

## [-->配置亿下](/subpages/conf.md)

